/* 
 * File:   GLFWApplication.cpp
 * Author: stuetzlec 
 * 
 * Created on October 10, 2017, 3:31 PM
 */

#include "SFMLApplication.h"

SFMLApplication::SFMLApplication() {
    
}

SFMLApplication::SFMLApplication(const SFMLApplication& orig) {

}

SFMLApplication::~SFMLApplication() {
}





int SFMLApplication::initializeApplication(int aaValue, // anti-aliasing level 
        int minorVersion, // OpenGL version
        int majorVersion,
        string winTitle, // The title of the window
        int winWidth, // Width and height of the window
        int winHeight
        ) {
    // Create the window
    sf::ContextSettings settings;
    settings.antialiasingLevel = aaValue;
    // If you are getting a failure, comment out these lines first:
    settings.majorVersion = majorVersion;
    settings.minorVersion = minorVersion;
    count = 0;
    srand(time(NULL));
    // Create a new SFML window
    window = new sf::Window(sf::VideoMode(winWidth, winHeight),
            winTitle, sf::Style::Default, settings);


    // To be safe, we’re using glew’s experimental stuff.
    glewExperimental = GL_TRUE;
    // Initialize and error check GLEW
    GLenum err = glewInit();
    if (GLEW_OK != err) {
        // If something went wrong, print the error message
        fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
    }

    glEnable(GL_DEPTH_TEST);
    glClearDepth(1.0f);
    
    // Set the time
    clock.restart();
    curTime = clock.getElapsedTime();
}

void SFMLApplication::initiateDrawLoop() {
    while (window -> isOpen()) {
        eventFunc(*window);
       
        draw();
        
    }
}

int SFMLApplication::getReverse(){
     if(reverse == 2){
            reverse = 0;
        }
        else{
        reverse++;
        }
    return reverse%2;
}

void SFMLApplication::draw() {    
    // Now, set the "delta time"
    double dt = clock.getElapsedTime().asSeconds() - curTime.asSeconds();
    curTime =  clock.getElapsedTime();
    camera -> setDeltaTime(dt);
    
    // Clears the given framebuffer (in this case, color and depth)
    // Could set color to clear to with glClearColor, default is black
    // Also clears the depth buffer, IMPORTANT because we're now in 3D
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Update the camera
    mat4 projectionMatrix = camera -> getPerspectiveMatrix();
    mat4 viewMatrix = camera -> getViewMatrix();
    mat4 VMMatrix; // Needed for the normals
    GLint PVMid;
    GLint VMid;
    GLint EyePositionid;
    
    for (int i = 0; i < lights.size(); i++) {
        lights[i]->connectLightToShader(shader1);
    }
    
    // Draw everything
    for (int i = 0; i < drawables.size(); i++) {
        if (drawables[i]) {
            mat4 modelMatrix = drawables[i] -> getModelMatrix();
            mat4 PVMMatrix = projectionMatrix * viewMatrix * modelMatrix;
          
            GLint PVMid = shader1 -> GetVariable("PVM");
            shader1 -> SetMatrix4(PVMid, 1, false, &PVMMatrix[0][0]);
            //drawables[i] ->getModelMatrix();
        
            drawables[i] ->draw(shader1);
            
            
            
        }
    }
    
    // Force OpenGL commands to begin executiond
    window -> display();
}

DrawableObject* SFMLApplication::select(){
    
   switch(count%3){
       case 0:
           count++;
           return drawables[0];
           break;
       case 1:
           count++;
           return drawables[1];
           break;
       case 2:
           count = 0;
           return drawables[2];
           break;
       
   }
   
   return NULL;
    
    
}

void SFMLApplication::clearLights(){
    while(!lights.empty()){
        lights.pop_back(); 
    }
    lights.resize(0);
}
// Add a drawable object to the class

void SFMLApplication::addDrawableObject(DrawableObject* o) {
    drawables.push_back(o);
}

void SFMLApplication::clearDrawables(){
    for(int i = drawables.size(); i > 5; i--){
        drawables.pop_back();
    }
}

void SFMLApplication::addLight(Light* l){
    lights.push_back(l);
}
