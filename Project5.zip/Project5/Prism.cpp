/* 
 * File:   Prism.cpp
 * Author: Patrick Langille
 * 
 * Created on November 15, 2017, 1:15 AM
 */

#include "Prism.h"
#include "AmbientLight.hpp"

/**
 * Constructor
 * @param _a top left vertex
 * @param _b top right vertex
 * @param _c bottom left vertex
 * @param t texture
 * @param h height
 */
Prism::Prism(vec3 _a, vec3 _b, vec3 _c, Texture* t, float h) {
    a = _a;
    b = _b;
    c = _c;
    d = vec3(_b.x, _b.y, _c.z); //uses previously existing vertices to get the last vertex
    height = h;
    tex = t;
    makePrism(a, b, c, h);
}

/**
 * Description: draws each rectangle that makes up the prism
 * @param s Shader
 */
void Prism::draw(Shader* s){
    for(int i = 0; i < recs.size(); i++){
        recs[i]->draw(s);
    }
}

/**
 * Description: sets the texture of the prism to the given Texture
 * @param t Texture
 */
void Prism::setTexture(Texture* t){
    tex = t;
    for(int i = 0; i < recs.size(); i++){
        recs[i]->setTexture(tex);
    }
}

/**
 * Description: gets the Y value of the upper base of the Prism (used primarily for placing blocks on top of each other)
 * @return 
 */
float Prism::getY(){
    return a.y + height;
}

/**
 * Description: detects collisions between two blocks, then places this Prism on
 * top of the other if there is a collision
 * @param p Prism
 */
void Prism::collision(Prism* p){
    if(((getMinX() >= p->getMinX() && getMinX() <= p->getMaxX()) || (getMaxX() >= p->getMinX() && getMaxX() <= p->getMaxX())) &&
           ((getMinZ() >= p->getMinZ() && getMinZ() <= p->getMaxZ()) || (getMaxZ() >= p->getMinZ() && getMaxZ() <= p->getMaxZ())))
    {
        while(!recs.empty()){
            recs.pop_back();
        }
        a.y = p->getY();
        makePrism(vec3(a.x, a.y, a.z), vec3(b.x, a.y, b.z), vec3(c.x, a.y, c.z), height);
    }
}

/**
 * Description: accesses the y value of the base of the Prism
 * @return 
 */
float Prism::getMinY(){
    return a.y;
}

/**
 * Description: accesses the minimum x value of the Prisms four vertices
 * @return 
 */
float Prism:: getMinX(){
    if(a.x <= b.x && a.x <= c.x && a.x <= d.x){
        return a.x;
    }
    else if(b.x <= d.x && b.x <= c.x){
        return b.x;
    }
    else if(c.x <= d.x){
        return c.x;
    }
    else
        return d.x;
}

/**
 * Description:accesses the maximum x value of the four vertices
 * @return 
 */
float Prism::getMaxX(){
    if(a.x >= b.x && a.x >= c.x && a.x >= d.x){
        return a.x;
    }
    else if(b.x >= d.x && b.x >= c.x){
        return b.x;
    }
    else if(c.x >= d.x){
        return c.x;
    }
    else
        return d.x;
}

/**
 * Description: accesses the minimum xz value of the Prism's four vertices
 * @return  
 */
float Prism::getMinZ(){
    if(a.z <= b.z && a.z <= c.z && a.z <= d.z){
        return a.z;
    }
    else if(b.z <= d.z && b.z <= c.z){
        return b.z;
    }
    else if(c.z <= d.z){
        return c.z;
    }
    else
        return d.z;
}

/**
 * Description: accesses the maximum z value of the four vertices 
 * @return 
 */
float Prism::getMaxZ(){
    if(a.z >= b.z && a.z >= c.z && a.z >= d.z){
        return a.z;
    }
    else if(b.z >= d.z && b.z >= c.z){
        return b.z;
    }
    else if(c.z >= d.z){
        return c.z;
    }
    else
        return d.z;
}

/**
 * Description: builds the 6 Rectangles and pushes them onto the vector
 * @param _a vertex
 * @param _b vertex
 * @param _c vertex
 * @param h height
 */
void Prism::makePrism(vec3 _a, vec3 _b, vec3 _c, float h){
    //bottom Rectangle
    Rectangle* r = new Rectangle(_a, _b, _c, vec3(_b.x, _b.y, _c.z),tex);
    recs.push_back(r);
    
    //top Rectangle
    r= new Rectangle(vec3(_a.x, _a.y + h, _a.z), vec3(_b.x, _b.y + h, _b.z), vec3(_c.x, _c.y +h, _c.z), vec3(_b.x, _b.y + h, _c.z), tex);
    recs.push_back(r);
    
    //front Rectangle
    r = new Rectangle(vec3(_c.x, _c.y + h, _c.z), vec3(_b.x, _b.y + h, _c.z), _c, vec3(_b.x, _b.y, _c.z), tex);
    recs.push_back(r);
    
    //back Rectangle
    r = new Rectangle(vec3(_a.x, _a.y + h, _a.z), vec3(_b.x, _b.y + h, _b.z), _a, _b, tex);
    recs.push_back(r);
    
    //left Rectangle
    r = new Rectangle(_a, vec3(_a.x, _a.y + h, _a.z) , _c, vec3(_c.x, _c.y + h, _c.z), tex);
    recs.push_back(r);
    
    //right Rectangle
    r = new Rectangle(vec3(_b.x, _b.y + h, _c.z), vec3(_b.x, _b.y + h, _b.z), vec3(_b.x, _b.y, _c.z), _b, tex);
    recs.push_back(r);
}

