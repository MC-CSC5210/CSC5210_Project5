/* 
 * File:   Prism.h
 * Author: Patrick Langille
 *
 * Created on November 15, 2017, 1:15 AM
 */

#ifndef PRISM_H
#define PRISM_H

#include <stdio.h>
#include <iostream>
#include <glm/glm.hpp>
#include "Shader.hpp"
#include "Texture.hpp"
#include "DrawableObject.h"
#include "Rectangle.h"

using glm::vec3;

using namespace std;

class Prism : public DrawableObject{
public:
    Prism(vec3, vec3, vec3, Texture*, float);
    void draw(Shader*);
    void setTexture(Texture*);
    float getY();
    void collision(Prism*);
    float getMinY();
    float getMinX();
    float getMaxX();
    float getMinZ();
    float getMaxZ();
    void makePrism(vec3, vec3, vec3, float);

private:
    std::vector<Rectangle*> recs;
    Texture* tex;
    float height;
    vec3 a;
    vec3 b;
    vec3 c;
    vec3 d;

};

#endif /* PRISM_H */
