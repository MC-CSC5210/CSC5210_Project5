/* 
 * File:   Prism.cpp
 * Author: Patrick Langille
 * 
 * Created on November 15, 2017, 1:15 AM
 */

#include "Prism.h"
#include "AmbientLight.hpp"

Prism::Prism(vec3 _a, vec3 _b, vec3 _c, Texture* t, float h) {
    a = _a;
    b = _b;
    c = _c;
    d = vec3(_b.x, _b.y, _c.z);
    height = h;
    tex = t;
    makePrism(a, b, c, h);
}


void Prism::draw(Shader* s){
    for(int i = 0; i < recs.size(); i++){
        recs[i]->draw(s);
    }
}

void Prism::setTexture(Texture* t){
    tex = t;
    for(int i = 0; i < recs.size(); i++){
        recs[i]->setTexture(tex);
    }
}

float Prism::getY(){
    return a.y + height;
}

void Prism::collision(Prism* p){
    if(((getMinX() >= p->getMinX() && getMinX() <= p->getMaxX()) || (getMaxX() >= p->getMinX() && getMaxX() <= p->getMaxX())) &&
           ((getMinZ() >= p->getMinZ() && getMinZ() <= p->getMaxZ()) || (getMaxZ() >= p->getMinZ() && getMaxZ() <= p->getMaxZ())))
    {
        while(!recs.empty()){
            recs.pop_back();
        }
        a.y = p->getY();
        makePrism(vec3(a.x, a.y, a.z), vec3(b.x, a.y, b.z), vec3(c.x, a.y, c.z), height);
    }
}

float Prism::getMinY(){
    return a.y;
}

float Prism:: getMinX(){
    if(a.x <= b.x && a.x <= c.x && a.x <= d.x){
        return a.x;
    }
    else if(b.x <= d.x && b.x <= c.x){
        return b.x;
    }
    else if(c.x <= d.x){
        return c.x;
    }
    else
        return d.x;
}

float Prism::getMaxX(){
    if(a.x >= b.x && a.x >= c.x && a.x >= d.x){
        return a.x;
    }
    else if(b.x >= d.x && b.x >= c.x){
        return b.x;
    }
    else if(c.x >= d.x){
        return c.x;
    }
    else
        return d.x;
}

float Prism::getMinZ(){
    if(a.z <= b.z && a.z <= c.z && a.z <= d.z){
        return a.z;
    }
    else if(b.z <= d.z && b.z <= c.z){
        return b.z;
    }
    else if(c.z <= d.z){
        return c.z;
    }
    else
        return d.z;
}

float Prism::getMaxZ(){
    if(a.z >= b.z && a.z >= c.z && a.z >= d.z){
        return a.z;
    }
    else if(b.z >= d.z && b.z >= c.z){
        return b.z;
    }
    else if(c.z >= d.z){
        return c.z;
    }
    else
        return d.z;
}

void Prism::makePrism(vec3 _a, vec3 _b, vec3 _c, float h){
    Rectangle* r = new Rectangle(_a, _b, _c, vec3(_b.x, _b.y, _c.z),tex);
    recs.push_back(r);
    
    r= new Rectangle(vec3(_a.x, _a.y + h, _a.z), vec3(_b.x, _b.y + h, _b.z), vec3(_c.x, _c.y +h, _c.z), vec3(_b.x, _b.y + h, _c.z), tex);
    recs.push_back(r);
    
    r = new Rectangle(vec3(_c.x, _c.y + h, _c.z), vec3(_b.x, _b.y + h, _c.z), _c, vec3(_b.x, _b.y, _c.z), tex);
    recs.push_back(r);
    
    r = new Rectangle(vec3(_a.x, _a.y + h, _a.z), vec3(_b.x, _b.y + h, _b.z), _a, _b, tex);
    recs.push_back(r);
    
    r = new Rectangle(_a, vec3(_a.x, _a.y + h, _a.z) , _c, vec3(_c.x, _c.y + h, _c.z), tex);
    recs.push_back(r);
    
    r = new Rectangle(vec3(_b.x, _b.y + h, _c.z), vec3(_b.x, _b.y + h, _b.z), vec3(_b.x, _b.y, _c.z), _b, tex);
    recs.push_back(r);
}

