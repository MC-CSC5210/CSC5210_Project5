/* 
 * File:   Prism.h
 * Author: Patrick Langille
 *
 * Created on November 15, 2017, 1:15 AM
 */

#ifndef PRISM_H
#define PRISM_H

#include <stdio.h>
#include <iostream>
#include <glm/glm.hpp>
#include "Shader.hpp"
#include "Texture.hpp"
#include "DrawableObject.h"
#include "Rectangle.h"

using glm::vec3;

using namespace std;

class Prism : public DrawableObject{
public:
    Prism(vec3, vec3, vec3, Texture*, float);
    void displayVertice(vec3);
    void draw(Shader*);
    void setTexture(Texture*);
    float getY();

private:
    std::vector<Rectangle*> recs;
    Texture* tex;

};

#endif /* PRISM_H */
