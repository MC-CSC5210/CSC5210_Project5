/*
 Created by Christopher Stuetzle (2017) 
 Slightly modified for my project3
 */

#include <iostream>
#include <cstdio>

// User Includes
#include "SFMLApplication.h"
#include "Shader.hpp"

#include "Camera.h"
#include "glm/glm.hpp"
#include "Rectangle.h"
#include "AmbientLight.hpp"
#include "Prism.h"

using namespace std;

// Window information
GLuint winHeight = 1080;
GLuint winWidth = 1920;

int reversed = 0;
int count = 0;
int light = 1;
// The current mouse position
double deltaX, deltaY;
bool lButtonDown;
bool rButtonDown;
vec2 mousePos;

// The one tetrahedron
vector<DrawableObject*> objects;
vector<DrawableObject*> store;
DrawableObject* selected;
Shader* s_1;
Shader* s_2;
Camera* c;
Texture* t;
Prism* terrain;
Prism* temp;
std::vector<Prism*> walls;
std::vector<Prism*> cubes;
Light* ambient;

SFMLApplication app;


// Init function to set up the geometry
// Pre: None
// Post: The quads are set up

void init() {

    t = new Texture("grass.png");
    terrain = new Prism(vec3(-500, 0, 2), vec3(500, 0, 2), vec3(-500, 0, 750), t, 2.0f);
    t = new Texture("brick.png");
    temp = new Prism(vec3(-500, 0, 0), vec3(502, 0, 0), vec3(-500, 0, 2), t, 10.0f);
    walls.push_back(temp);
    temp = new Prism(vec3(-502, 0, 0), vec3(-500, 0, 0), vec3(-502, 0, 750), t, 10.0f);
    walls.push_back(temp);
    temp = new Prism(vec3(-502, 0, 750), vec3(500, 0, 750), vec3(-502, 0, 752), t, 10.0f);
    walls.push_back(temp);
    temp = new Prism(vec3(500, 0, 2), vec3(502, 0, 2), vec3(500, 0, 752), t, 10.0f);
    walls.push_back(temp);
   
    app.addDrawableObject(terrain);
    for(int i =0; i < walls.size(); i++){
        app.addDrawableObject(walls[i]);
    }
    // Set up the shader
    string shaders1[] = {"Texture.vert", "Texture.frag"};
    s_1 = new Shader(shaders1, true);
    // Set up the camera
    vec3 pos(0, 9, 26);
    GLfloat FOV = 45.0f;
    GLfloat nearPlane = 0.1f;
    GLfloat farPlane = 1000.0f;
    c = new Camera(pos, winWidth, winHeight);
    c -> setPerspective(FOV, (GLfloat) winWidth / (GLfloat) winHeight,
            nearPlane, farPlane);
    ambient = new AmbientLight(vec3(0.5, 0.5, 0.5));
    app.addLight(ambient);

}

void handleEvents(sf::Window& window) {
    sf::Event event;
    float pow = 0.5;
    bool debug = false;
    // While there are still events.
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        } else if (event.type == sf::Event::Resized) {
            winHeight = event.size.height;
            winWidth = event.size.width;
            glViewport(0, 0, winWidth, winHeight);
        }// Keyboard pressed
        else if (event.type == sf::Event::KeyReleased) {
            if (event.key.code == sf::Keyboard::Q) {
                window.close();
            }
            else if (event.key.code == sf::Keyboard::L){
                if(light == 1){
                    ambient->setColor(vec3(0.75, 0.75, 0.75));
                    light = 0;
                     
                }
                else{
                    ambient->setColor(vec3(0.5, 0.5, 0.5));
                    light = 1;
                }
                
                app.clearLights();
                app.addLight(ambient);
            }
            else if(event.key.code == sf::Keyboard::W){
                if((c->getPosition().x + c->getViewVector().x) > -500 && (c->getPosition().x + c->getViewVector().x) < 500 &&
                       (c->getPosition().z +c->getViewVector().z) > 2.2 && (c->getPosition().z +c->getViewVector().z) < 750){
                c->setPosition(c->getPosition().x+c->getViewVector().x, c->getPosition().y, c->getPosition().z +c->getViewVector().z);
                if(debug){
                    cout<<"Moved Forward, ";
                    cout<<"ViewVector = ";
                    cout<<"( "<<c->getViewVector().x;
                    cout<<", "<<c->getViewVector().y;
                    cout<<", "<<c->getViewVector().z<<"), ";
                    cout<<"RightVector = ";
                    cout<<"( "<<c->getRightVector().x;
                    cout<<", "<<c->getRightVector().y;
                    cout<<", "<<c->getRightVector().z<<")"<<endl;
                    
           
                }
                }
            }
            else if(event.key.code == sf::Keyboard::A){
                if((c->getPosition().x - c->getRightVector().x) > -500 && (c->getPosition().x - c->getRightVector().x) < 500 &&
                       (c->getPosition().z - c->getRightVector().z) > 2.2 && (c->getPosition().z - c->getRightVector().z) < 750){
                c->setPosition(c->getPosition().x - c->getRightVector().x, c->getPosition().y, c->getPosition().z - c->getRightVector().z);
                if(debug){
                    cout<<"Moved Left, ";
                    cout<<"ViewVector = ";
                    cout<<"( "<<c->getViewVector().x;
                    cout<<", "<<c->getViewVector().y;
                    cout<<", "<<c->getViewVector().z<<"), ";
                    cout<<"RightVector = ";
                    cout<<"( "<<c->getRightVector().x;
                    cout<<", "<<c->getRightVector().y;
                    cout<<", "<<c->getRightVector().z<<")"<<endl;

           
                }
                }
            }
            else if(event.key.code == sf::Keyboard::S){
                if((c->getPosition().x - c->getViewVector().x) > -500 && (c->getPosition().x - c->getViewVector().x) < 500
                        && (c->getPosition().z - c->getViewVector().z) > 2.2 && (c->getPosition().z - c->getViewVector().z) < 750){
                c->setPosition(c->getPosition().x - c->getViewVector().x, c->getPosition().y, c->getPosition().z - c->getViewVector().z);
                if(debug){
                    cout<<"Moved Backward, ";
                    cout<<"ViewVector = ";
                    cout<<"( "<<c->getViewVector().x;
                    cout<<", "<<c->getViewVector().y;
                    cout<<", "<<c->getViewVector().z<<"), ";
                    cout<<"RightVector = ";
                    cout<<"( "<<c->getRightVector().x;
                    cout<<", "<<c->getRightVector().y;
                    cout<<", "<<c->getRightVector().z<<")"<<endl;
                }

           
                }
            }
            else if(event.key.code == sf::Keyboard::D){
                if((c->getPosition().x + c->getRightVector().x) > -500 && (c->getPosition().x + c->getRightVector().x) < 500 &&
                       (c->getPosition().z +c->getRightVector().z) > 2.2 && (c->getPosition().z +c->getRightVector().z) < 750){
            
                c->setPosition(c->getPosition().x+c->getRightVector().x, c->getPosition().y, c->getPosition().z + c->getRightVector().z);
                if(debug){
                    cout<<"Move Right, ";
                    cout<<"ViewVector = ";
                    cout<<"( "<<c->getViewVector().x;
                    cout<<", "<<c->getViewVector().y;
                    cout<<", "<<c->getViewVector().z<<"), ";
                    cout<<"RightVector = ";
                    cout<<"( "<<c->getRightVector().x;
                    cout<<", "<<c->getRightVector().y;
                    cout<<", "<<c->getRightVector().z<<")"<<endl;
           
                }
                }
            }
            else if(event.key.code == sf::Keyboard::R){
                c->setPosition(c->getPosition().x, c->getPosition().y + pow, c->getPosition().z);
                if(debug){
                    cout<<"Move Upward, ";
                    cout<<"ViewVector = ";
                    cout<<"( "<<c->getViewVector().x;
                    cout<<", "<<c->getViewVector().y;
                    cout<<", "<<c->getViewVector().z<<"), ";
                    cout<<"RightVector = ";
                    cout<<"( "<<c->getRightVector().x;
                    cout<<", "<<c->getRightVector().y;
                    cout<<", "<<c->getRightVector().z<<")"<<endl;
           
                }
            }
            else if(event.key.code == sf::Keyboard::F){
                c->setPosition(c->getPosition().x, c->getPosition().y - pow, c->getPosition().z);
                if(debug){
                    cout<<"Move Downward, ";
                    cout<<"ViewVector = ";
                    cout<<"( "<<c->getViewVector().x;
                    cout<<", "<<c->getViewVector().y;
                    cout<<", "<<c->getViewVector().z<<"), ";
                    cout<<"RightVector = ";
                    cout<<"( "<<c->getRightVector().x;
                    cout<<", "<<c->getRightVector().y;
                    cout<<", "<<c->getRightVector().z<<")"<<endl;
           
                }
            }
            else if(event.key.code == sf::Keyboard::P){
                temp = new Prism(vec3(((c->getViewVector().x*20 + c->getPosition().x) - 5), 2, ((c->getViewVector().z*20 + c->getPosition().z) + 5)),
                        vec3(((c->getViewVector().x*20 + c->getPosition().x) + 5), 2, ((c->getViewVector().z*20 + c->getPosition().z) + 5)),
                        vec3(((c->getViewVector().x*20 + c->getPosition().x) - 5), 2, ((c->getViewVector().z*20 + c->getPosition().z) - 5)),
                        t, 5.0f);
                app.addDrawableObject(temp);
            }
            else if(event.key.code == sf::Keyboard::Num1){
                t = new Texture("brick.png");
            }
            else if(event.key.code == sf::Keyboard::Num2){
                t = new Texture("wood.png");
            }
            else if(event.key.code == sf::Keyboard::Num3){
                t = new Texture("mud.png");
            }
            else if(event.key.code == sf::Keyboard::Num4){
                t = new Texture("water.png");
            }
            else if(event.key.code == sf::Keyboard::Num5){
                t = new Texture("concrete.png");
            }
            else if(event.key.code == sf::Keyboard::Num6){
                t = new Texture("metal.png");
            }
            else if(event.key.code == sf::Keyboard::Num7){
                t = new Texture("grass.png");
            }
        }            // Mouse button pressed  
        else if (event.type == sf::Event::MouseButtonReleased) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                lButtonDown = false;
            } else if (event.mouseButton.button == sf::Mouse::Right) {
                rButtonDown = false;
            }
        } else if (event.type == sf::Event::MouseButtonPressed) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                lButtonDown = true;
            } else if (event.mouseButton.button == sf::Mouse::Right) {
               rButtonDown = true;
            }
        } else if (event.type == sf::Event::MouseMoved) {
            sf::Vector2i m = sf::Mouse::getPosition();
            deltaX = mousePos.x - m.x;
            deltaY = mousePos.y - m.y;
            mousePos.x = m.x;
            mousePos.y = m.y;
            
            // If the associated button is down, make sure to 
            //   update the camera accordingly.
            if (lButtonDown) {
                c -> setViewByMouse(deltaX, deltaY);
            }
            if (rButtonDown) {
                // This is negative BECAUSE THE LOOK VECTOR IS BACKWARDS...hack
                //c -> moveCamera(-deltaX, deltaY, 26);
            }
        }
      
    }
}

int main() {
    // Set up the GLFW application
    app.initializeApplication(8, 3, 3,
            "Minecraft", winWidth, winHeight);

    // Assign your callback functions (the ones you write) to the internal
    //   callbacks of the application class.
    app.setCallback(handleEvents);

    // Initialize stuff local to the program
    init();
    app.setShader(s_1);
    app.setCamera(c);

    // Tell the application to "go"
    app.initiateDrawLoop();



    return 0;
}

