/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DirectionalLight.h
 * Author: m228student
 *
 * Created on November 20, 2017, 4:27 PM
 */

#ifndef DIRECTIONALLIGHT_H
#define DIRECTIONALLIGHT_H
#include "Light.hpp"
#include "glm/glm.hpp"

using glm::vec3;

class DirectionalLight : public Light {
public:
    DirectionalLight(vec3 col, vec3 dir, GLfloat st, GLfloat sh);
    void connectLightToShader(Shader*);
private:
    vec3 direction;
    GLfloat shininess;
    GLfloat strength;
};

#endif /* DIRECTIONALLIGHT_H */

