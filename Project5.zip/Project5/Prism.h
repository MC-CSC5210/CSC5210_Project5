/* 
 * File:   Prism.h
 * Author: Patrick Langille
 *
 * Created on November 15, 2017, 1:15 AM
 */

#ifndef PRISM_H
#define PRISM_H

#include <stdio.h>
#include <iostream>
#include <glm/glm.hpp>
#include "Shader.hpp"
#include "Texture.hpp"
#include "DrawableObject.h"
#include "Rectangle.h"

using glm::vec3;

using namespace std;

class Prism : public DrawableObject{
public:
    Prism(vec3, vec3, vec3, Texture*, float);
    void draw(Shader*); //draws each rectangle
    void setTexture(Texture*); //sets the texture of the prism
    float getY();//returns the y value at the top of the prism
    void collision(Prism*);//detects collision between two prisms
    float getMinY();//returns the base y value
    float getMinX();//finds the minimum x value in the prism
    float getMaxX();// finds the maximum x value in the prism
    float getMinZ();//finds the minimum z value in the prism
    float getMaxZ();//finds the maximum z value in the prism
    void makePrism(vec3, vec3, vec3, float);//builds the prism out of rectangles

private:
    std::vector<Rectangle*> recs; //holds the rectangles that make up the prism
    Texture* tex; //the texture of the prism
    float height; // the height of the prism
    vec3 a;
    vec3 b;
    vec3 c;
    vec3 d;

};

#endif /* PRISM_H */
