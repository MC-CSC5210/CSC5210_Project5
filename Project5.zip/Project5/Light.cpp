#include "Light.hpp"

Light::Light( vec3 col ){
    enabled = true;
    color = col;
}