/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AmbientLight.cpp
 * Author: stuetzlec
 * 
 * Created on October 27, 2017, 1:30 PM
 */

#include "AmbientLight.hpp"

AmbientLight::AmbientLight(vec3 col) : Light(col) {
    setColor(vec3(0.15, 0.15, 0.15));
}

AmbientLight::AmbientLight(const AmbientLight& orig) : Light(orig) {

}

AmbientLight::~AmbientLight() {
}

void AmbientLight::connectLightToShader(Shader* s) {
    GLuint aL = s->GetVariable("cAmbient");
    s->SetVector3(aL, 1, &color[0]);

    GLint weight = s->GetVariable("wAmbient");
    if (isEnabled())
        s->SetFloat(weight, 0.2);
    else
        s->SetFloat(weight, 0.0);
}