/* 
 * File:   Prism.cpp
 * Author: Patrick Langille
 * 
 * Created on November 15, 2017, 1:15 AM
 */

#include "Prism.h"

Prism::Prism(vec3 _a, vec3 _b, vec3 _c, Texture* t, float h) {
    bool debug = true;
    Rectangle* r = new Rectangle(_a, _b, _c, vec3(_b.x, _b.y, _c.z),t);
    recs.push_back(r);
    if(debug){
        cout<<"rectangle: ";
        displayVertice(_a);
        displayVertice(_b);
        displayVertice(_c);
        cout<<endl;
    }
    r= new Rectangle(vec3(_a.x, _a.y + h, _a.z), vec3(_b.x, _b.y + h, _b.z), vec3(_c.x, _c.y +h, _c.z), vec3(_b.x, _b.y + h, _c.z), t);
    recs.push_back(r);
    if(debug){
        cout<<"rectangle: ";
        displayVertice(vec3(_a.x, _a.y + h, _a.z));
        displayVertice(vec3(_b.x, _b.y + h, _b.z));
        displayVertice(vec3(_c.x, _c.y +h, _c.z));
        cout<<endl;
    }
    r = new Rectangle(vec3(_c.x, _c.y + h, _c.z), vec3(_b.x, _b.y + h, _c.z), _c, vec3(_b.x, _b.y, _c.z), t);
    recs.push_back(r);
    if(debug){
        cout<<"rectangle: ";
        displayVertice(vec3(_c.x, _c.y + h, _c.z));
        displayVertice(vec3(_b.x, _c.y + h, _c.z));
        displayVertice(_c);
        cout<<endl;
    }
    r = new Rectangle(vec3(_a.x, _a.y + h, _a.z), vec3(_b.x, _b.y + h, _b.z), _a, _b, t);
    recs.push_back(r);
    if(debug){
        cout<<"rectangle: ";
        displayVertice(vec3(_a.x, _a.y + h, _a.z));
        displayVertice(vec3(_b.x, _b.y + h, _b.z));
        displayVertice(_a);
        cout<<endl;
    }
    r = new Rectangle(_a, vec3(_a.x, _a.y + h, _a.z) , _c, vec3(_c.x, _c.y + h, _c.z), t);
    recs.push_back(r);
    if(debug){
        cout<<"rectangle: ";
        displayVertice(vec3(_a.x, _a.y + h, _a.z));
        displayVertice(vec3(_c.x, _c.y + h, _c.z));
        displayVertice(_a);
        cout<<endl;
    }
    r = new Rectangle(vec3(_b.x, _b.y + h, _c.z), vec3(_b.x, _b.y + h, _b.z), vec3(_b.x, _b.y, _c.z), _b, t);
    recs.push_back(r);
    if(debug){
        cout<<"rectangle: ";
        displayVertice(vec3(_b.x, _c.y + h, _c.z));
        displayVertice(vec3(_b.x, _b.y + h, _b.z));
        displayVertice(vec3(_b.x, _c.y, _c.z));
        cout<<endl;
    }
    tex = t;
}

void Prism::displayVertice(vec3 v){
    cout<<"("<<v.x<<","<<v.y<<","<<v.z<<") ";
}

void Prism::draw(Shader* s){
    for(int i = 0; i < recs.size(); i++){
        recs[i]->draw(s);
    }
}

void Prism::setTexture(Texture* t){
    tex = t;
    for(int i = 0; i < recs.size(); i++){
        recs[i]->setTexture(tex);
    }
}



